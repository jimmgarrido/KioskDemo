﻿using MOVAI.iOS.Effects;
using System;
using System.ComponentModel;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ResolutionGroupName("Microsoft")]
[assembly: ExportEffect(typeof(ContentInsetAdjustmentBehaviorEffect), "ContentInsetAdjustmentBehaviorEffect")]
namespace MOVAI.iOS.Effects
{
	public class ContentInsetAdjustmentBehaviorEffect : PlatformEffect
	{
       
		protected override void OnAttached()
		{
			try
			{
				var scroll = Control as UIScrollView;
				scroll.ContentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentBehavior.Never;
				var inset = (Thickness)Element.GetValue(MOVAI.Effects.ContentInsetAdjustmentBehavior.ContentInsetProperty);
				scroll.ContentInset = new UIEdgeInsets((nfloat)inset.Top, (nfloat)inset.Left, (nfloat)inset.Bottom, (nfloat)inset.Right);
			}
			catch (Exception ex)
			{
				Console.WriteLine("Cannot set property on attached control. Error: ", ex.Message);
			}
		}

		protected override void OnDetached()
		{
		}

		protected override void OnElementPropertyChanged(PropertyChangedEventArgs args)
		{
			base.OnElementPropertyChanged(args);

			try
			{
				if (args.PropertyName == "ContentInset")
				{
					var scroll = Control as UIScrollView;
					var inset = (Thickness)Element.GetValue(MOVAI.Effects.ContentInsetAdjustmentBehavior.ContentInsetProperty);
					scroll.ContentInset = new UIEdgeInsets((nfloat)inset.Top, (nfloat)inset.Left, (nfloat)inset.Bottom, (nfloat)inset.Right);

				}
			}
			catch (Exception ex)
			{

			}
		}
		//        if (args.PropertyName == "IsFocused")
		//        {
		//            if (Control.BackgroundColor == backgroundColor)
		//            {
		//                Control.BackgroundColor = UIColor.White;
		//            }
		//            else
		//            {
		//                Control.BackgroundColor = backgroundColor;
		//            }
		//        }
		//    }
		//    catch (Exception ex)
		//    {
		//        Console.WriteLine("Cannot set property on attached control. Error: ", ex.Message);
		//    }
		//}
	}
}