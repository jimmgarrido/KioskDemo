﻿using System;
using MOVAI.Services;
using Xamarin.Essentials;

namespace MOVAI.iOS.Services
{
    public class MediaFolder : IMediaFolder
    {
        public string Path {
            get{
                return FileSystem.AppDataDirectory;
            }
        }
    }
}
