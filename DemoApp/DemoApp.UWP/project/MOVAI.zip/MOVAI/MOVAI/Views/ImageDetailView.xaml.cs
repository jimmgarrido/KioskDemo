﻿using Xamarin.Forms;
using MOVAI.ViewModels;
using SkiaSharp.Views.Forms;
using SkiaSharp;
using MOVAI.Services;
using System.Collections.Generic;
using System;
using System.ComponentModel;

namespace MOVAI.Views
{
	public partial class ImageDetailView : ContentPage
	{
		private ImageDetailViewModel vm;

		public ImageDetailViewModel VM
		{
			get => vm; set
			{
				vm = value;
				BindingContext = vm;
			}
		}

		void OnCanvasViewPaintSurface(object sender, SKPaintSurfaceEventArgs args)
		{
			var w = args.Info.Size.Width;
			var h = args.Info.Size.Height;
			var surface = args.Surface;
			var canvas = surface.Canvas;
			canvas.Clear(SKColors.Transparent);

			var paint = new SKPaint
			{
				IsAntialias = true,
				Style = SKPaintStyle.Fill,
				Color = SKColor.Parse("#FFFFFF"),
				StrokeWidth = 0
			};

			var path = new SKPath { FillType = SKPathFillType.EvenOdd };
			path.MoveTo(0, h);
			path.LineTo(w, h);
			path.LineTo(w, 0);
			path.LineTo(0, h);
			path.Close();
			canvas.DrawPath(path, paint);
		}

		void Handle_Clicked(object sender, System.EventArgs e)
		{
			var share = DependencyService.Get<IShare>();
            share.Show("Title", "Message", vm.ImageSource);
		}

		public ImageDetailView()
		{
			InitializeComponent();
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();
			this.Padding = 0;

            NavigationPage.SetBackButtonTitle(this, string.Empty);

            DisplayAchievements();

            vm.PropertyChanged += WhenPropertyChanged;
		}

        private void WhenPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName == nameof(vm.Achievements))
            {
                DisplayAchievements();
            }
        }

        void DisplayAchievements()
        {
            AchievementsContainer.Children.Clear();
            if (vm?.Achievements.Count > 0)
            {
                GetAchievementsButton.IsEnabled = GetAchievementsButton.IsVisible = false;

                foreach (var achievement in vm?.Achievements)
                {
                    AchievementsContainer.Children.Add(
                    new Image
                    {
                        StyleClass = new List<string> { "achievement" },
                        Source = (achievement.HasDarkImage) ? $"{achievement.Icon}Dark" : achievement.Icon
                    });
                }
                AchievementsContainer.IsVisible = true;
            }
            else
            {
                AchievementsContainer.IsVisible = false;
                GetAchievementsButton.IsEnabled = GetAchievementsButton.IsVisible = true;
            }

        }

        async void Handle_DeleteClickedAsync(object sender, System.EventArgs e)
        {
            VM.DeleteCommand.Execute(null);
            await Navigation.PopAsync();
		}

		async void Handle_AnalyzeClickedAsync(object sender, System.EventArgs e)
        {
            if (DateTime.Today > DateTime.Parse("5/13/2018"))
            {
                var result = await DisplayAlert("Vision Key Expired", "Thanks for using the app! To continue using the Vision API, please visit the website and signup for your free trial key.", "Go Now", "Maybe Later");
                if (result == true)
                {
                    await Xamarin.Essentials.Browser.OpenAsync("https://azure.microsoft.com/en-us/services/cognitive-services/computer-vision/");
                }
            }
            else
            {
                GetVisionResultsButton.IsEnabled = false;
                VM.GetVisionResultsCommand.Execute(null);
            }
        }
        void Handle_CheckAchievementsClickedAsync(object sender, System.EventArgs e)
        {
            GetAchievementsButton.IsEnabled = false;
            VM.GetAchievementsCommand.Execute(null);
        }
    }
}