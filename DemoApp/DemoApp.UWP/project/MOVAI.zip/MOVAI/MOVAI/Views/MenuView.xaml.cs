﻿using MOVAI.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MOVAI.Views
{
	public partial class MenuView : ContentPage
	{
		public ListView ListView;

		public Button CloseButton;

		public Button SettingsButton;

		public MenuView()
		{
			InitializeComponent();

			BindingContext = new MasterViewModel();
			ListView = menuItemsListView;
			CloseButton = closeButton;
			SettingsButton = settingsButton;

		}

		async void DisplayQRShareCode(object sender, System.EventArgs e)
		{
			await Navigation.PushModalAsync(new HomeworkView() { MarkdownFile = "ShareApp.md" }, true);
		}
	}
}