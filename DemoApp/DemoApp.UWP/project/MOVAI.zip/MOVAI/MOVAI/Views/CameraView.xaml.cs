﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MOVAI.Models;
using MOVAI.Services;
using MOVAI.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MOVAI.Views
{
	public partial class CameraView : ContentPage
	{
        CameraViewModel vm;

		public CameraViewModel ViewModel
        {
            get => vm; set
            {
                vm = value;
                BindingContext = vm;
            }
        }

        public CameraView ()
		{
			InitializeComponent ();
			if (vm == null)
				ViewModel = new CameraViewModel();
		}

		private double width = 0;
		private double height = 0;

		protected override void OnSizeAllocated(double width, double height)
		{
			base.OnSizeAllocated(width, height); //must be called
			if (this.width != width || this.height != height)
			{
				this.width = width;
				this.height = height;

				VisualStateManager.GoToState(Container, (width > height) ? "Horizontal" : "Portrait");
				VisualStateManager.GoToState(LastImage, (width > height) ? "Horizontal" : "Portrait");
			}
		}

		void OnCaptureTapped(object sender, EventArgs args)
		{
			Camera.StartRecording();
		}

		async void OnCloseAsync(object sender, EventArgs e)
		{
			await Navigation.PopModalAsync(true);
		}

		async void NavToDetailAsync(object sender, System.EventArgs e)
		{
			MessagingCenter.Send<CameraView, Memory>(this, "GoToImage", vm.LastMemory);
			await Navigation.PopModalAsync(true);
		}
	}
}