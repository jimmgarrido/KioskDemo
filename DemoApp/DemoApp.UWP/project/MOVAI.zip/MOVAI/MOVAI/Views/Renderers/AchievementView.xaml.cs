﻿using System;
using System.Collections.Generic;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace MOVAI.Views.Renderers
{
	public partial class AchievementView : Grid
	{
		public AchievementView()
		{
			InitializeComponent();
		}

		public static readonly BindableProperty IconProperty =
			BindableProperty.Create(nameof(Icon), typeof(string), typeof(AchievementView), "");
		public string Icon
		{
			get { return (string)GetValue(IconProperty); }
			set { SetValue(IconProperty, value); OnPropertyChanged(nameof(Icon)); }
		}
		public static readonly BindableProperty AchievementProperty =
			BindableProperty.Create(nameof(Achievement), typeof(string), typeof(AchievementView), "");

		public string Achievement
		{
			get { return (string)GetValue(AchievementProperty); }
			set { SetValue(AchievementProperty, value); OnPropertyChanged(nameof(Achievement)); }
		}

		private bool isAchieved;
		public bool IsAchieved
		{
			set
			{
				isAchieved = value;
				//this.Circle.Fill = isAchieved ? new SolidColorBrush { Color = Color.Black } : new SolidColorBrush { Color = Color.DimGray };
				this.IsVisible = isAchieved;
			}
		}

		public string Url { get; set; }

		async void OpenUrl_ClickedAsync(object sender, System.EventArgs e)
		{
			if (!string.IsNullOrEmpty(Url))
				await Browser.OpenAsync(Url);
		}
	}
}
