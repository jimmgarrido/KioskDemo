﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MOVAI.ViewModels;
using MOVAI.Views.Renderers;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MOVAI.Views
{
	public partial class AchievementsView : ContentPage
	{
		AchievementsViewModel vm;

		public AchievementsViewModel ViewModel
		{
			get => vm; set
			{
				vm = value;
				BindingContext = vm;
			}
		}


		public AchievementsView()
		{
			InitializeComponent();
			if (vm == null)
				ViewModel = new AchievementsViewModel();
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();

			vm?.OnAppearing();

			AchievementsContainer.Children.Clear();
			foreach (var achievement in vm.Achievements)
			{
				AchievementsContainer.Children.Add(
					new AchievementView
					{
						Achievement = achievement.Name,
						Icon = achievement.Icon,
						IsAchieved = true,
						StyleClass = new List<string> { "item" },
						Url = achievement.Url
					}
				);
			}


			this.UpdateChildrenLayout();
		}
	}
}