﻿namespace MOVAI.Models
{
	public class Achievement
	{
		public string Name { get; set; }
		public string Icon { get; set; }
		public bool IsAchieved { get; set; }
		public string Url { get; set; }
		public bool HasDarkImage { get; set; }
	}
}