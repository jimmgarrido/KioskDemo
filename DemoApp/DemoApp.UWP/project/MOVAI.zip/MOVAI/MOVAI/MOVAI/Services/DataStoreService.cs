﻿using System;
using System.IO;
using System.Xml.Serialization;
using MOVAI.Models;
using Xamarin.Essentials;

namespace MOVAI.Services
{
    public class DataStoreService
    {
        public void Save(DataStore model)
        {
			//model.Memories.Sort((x, y) => DateTime.Compare(x.CreatedAt, y.CreatedAt));

            var serializer = new XmlSerializer(model.GetType());
            var stringWriter = new StringWriter();
            serializer.Serialize(stringWriter, model);

            Preferences.Set("DataStore", stringWriter.ToString());
           
        }

        public void Load(DataStore model)
        {
            var serializer = new XmlSerializer(typeof(DataStore));
            var dataString = Preferences.Get("DataStore", string.Empty);
            var stringReader = new StringReader(dataString);
            
            try
            {
				App.DataStore = (DataStore)serializer.Deserialize(stringReader);
            }
            catch
            {
				App.DataStore = new DataStore();
				Save(App.DataStore);
            }
        }

        public void SaveMemory(Memory memory)
        {
            // find memory in DataStore, update/replace it, persist
        }

        public void DeleteMemory(Memory memory)
        {
            App.DataStore.Memories.Remove(memory);
            Save(App.DataStore);
        }
    }
}
