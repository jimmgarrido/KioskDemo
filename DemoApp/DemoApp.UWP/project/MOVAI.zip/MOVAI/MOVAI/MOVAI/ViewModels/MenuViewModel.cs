﻿using System;
using System.Windows.Input;
using MOVAI.ViewModels.Base;

namespace MOVAI.ViewModels
{
	public class MenuViewModel : ViewModelBase
    {
		


		public MenuViewModel()
        {
        }


    }
}
