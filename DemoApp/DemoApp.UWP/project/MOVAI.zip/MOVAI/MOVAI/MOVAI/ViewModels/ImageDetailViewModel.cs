﻿using System.Collections.Generic;
using System.IO;
using System.Collections.ObjectModel;
using System.Windows.Input;
using MOVAI.Models;
using MOVAI.Services;
using MOVAI.ViewModels.Base;
using Xamarin.Forms;
using System.Linq;

namespace MOVAI.ViewModels
{
	public class ImageDetailViewModel : ViewModelBase
	{
		Memory memory;
		public Memory Memory
		{
			get => memory; 
			set
			{
				memory = value;
				OnPropertyChanged();
				OnPropertyChanged(nameof(VisionNotes));
                OnPropertyChanged(nameof(VisionTags));
			}
		}

		public string ImageSource => memory.MediaPath;
		public string VisionNotes => Memory == null ? "" : Memory.Notes;  
		public string VisionTags => Memory == null ? "" : string.Join(" ", Memory.Tags);

		public List<Achievement> Achievements => memory.Achievements;
        
		public ICommand DeleteCommand;
		public ICommand GetVisionResultsCommand;
        public ICommand GetAchievementsCommand;

        public ImageDetailViewModel()
		{
			DeleteCommand = new Command(HandleDelete);
			GetVisionResultsCommand = new Command(HandleVision);
            GetAchievementsCommand = new Command(HandleAchievements);
		}
        
		void HandleDelete(object obj)
		{
			DependencyService.Get<DataStoreService>().DeleteMemory(memory);
		}

        async void HandleAchievements(object obj)
        {
            await DependencyService.Get<VisionService>().DetectAchievements(memory);

            OnPropertyChanged(nameof(Achievements));
        }

		async void HandleVision(object obj)
		{
            IsProcessingVision = true;
			await DependencyService.Get<VisionService>().AnalyzeImage(memory);
		

            OnPropertyChanged(nameof(VisionNotes));
            OnPropertyChanged(nameof(VisionTags));
            OnPropertyChanged(nameof(HasNoVisionResults));

            var oldItem = App.DataStore.Memories.FirstOrDefault(e => e.Id == memory.Id);

			if (oldItem == null)
			{
				App.DataStore.Memories.Insert(0, memory);
			}
			else
			{
				var index = App.DataStore.Memories.IndexOf(oldItem);
				App.DataStore.Memories.Remove(oldItem);
				App.DataStore.Memories.Insert(index, memory);
			}

            DependencyService.Get<DataStoreService>().Save(App.DataStore);
            IsProcessingVision = false;
			// TODO if after X date, pop message that Build key is no longer valid and the user needs their own key, link to activity
		}

        public bool HasNoVisionResults
        {
            get
            {
                if (isProcessingVision)
                    return false;

                return (string.IsNullOrEmpty(VisionNotes) && string.IsNullOrEmpty(VisionTags));
            }
        }

        private bool isProcessingVision;
        public bool IsProcessingVision
        {
            get
            {
                return isProcessingVision;
            }
            set
            {
                isProcessingVision = value;
                OnPropertyChanged(nameof(IsProcessingVision));
                OnPropertyChanged(nameof(HasNoVisionResults));
            }
        }
	}
}