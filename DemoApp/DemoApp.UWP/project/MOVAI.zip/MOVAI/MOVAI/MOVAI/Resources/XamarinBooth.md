﻿# How to Find the Xamarin Booth

In the Expo hall, go to _____