﻿using MOVAI.Models;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MOVAI.Views
{
    public partial class MasterView : MasterDetailPage
    {
        public MasterView()
        {
            InitializeComponent();
            Menu.ListView.ItemSelected += ListView_ItemSelected;
            Menu.SettingsButton.Clicked += Settings_Clicked;
            Menu.CloseButton.Clicked += Close_Clicked;

            
        }

        private void Close_Clicked(object sender, EventArgs e)
        {
            IsPresented = false;
        }

        private void ListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var item = e.SelectedItem as MasterViewMenuItem;
            if (item == null)
                return;

            var page = (Xamarin.Forms.Page)Activator.CreateInstance(item.TargetType);
            //page.Title = item.Title;

            Detail = new CustomNavigationPage(page)
            {
                BackgroundColor = Color.Transparent,
				BarBackgroundColor = Color.Transparent
            };
            IsPresented = false;
            Menu.ListView.SelectedItem = null;
        }

        async void Settings_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new SettingsView(), true);
        }
    }
}