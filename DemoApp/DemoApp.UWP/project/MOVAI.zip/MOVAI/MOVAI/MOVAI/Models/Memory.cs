﻿using System;
using System.Collections.Generic;

namespace MOVAI.Models
{
    public class Memory
    {
		public string Id { get; } = Guid.NewGuid().ToString("N");    

		public bool Liked { get; set; }
        public string MediaPath { get; set; }
		public List<Achievement> Achievements { get; set; } = new List<Achievement>();
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; }
		public string Notes { get; set; }
		public List<string> Tags { get; set; } = new List<string>();
    }
}
