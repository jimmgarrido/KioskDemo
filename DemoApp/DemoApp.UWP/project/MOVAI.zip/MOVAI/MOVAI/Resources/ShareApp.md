﻿# Share the App

Scan this QR Code and you'll get all the details for both the app and the code!

![QR Code](Images/qrcode.png)