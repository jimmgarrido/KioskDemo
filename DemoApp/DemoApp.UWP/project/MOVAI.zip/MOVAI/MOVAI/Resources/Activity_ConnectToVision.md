﻿# Homework 1
Do something amazing.