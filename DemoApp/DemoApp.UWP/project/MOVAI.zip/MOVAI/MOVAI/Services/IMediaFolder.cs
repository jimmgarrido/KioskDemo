﻿using System;
namespace MOVAI.Services
{
    public interface IMediaFolder
    {
        string Path { get; }
    }
}
