# MOVAI
Mobile Vision AI

https://sketch.cloud/s/keVVA/all/build/main-image-feed/play

The features to make functional in order of priority:
[X] Navigation and Side Menu
[] Main list of photos
[X] Camera take a Photo
[] Vision
[] Photo detail view
[] Achievements
[] Share
[] Search
[] User Profile

## Dependencies
### Live Reload Preview is Windows only. On macOS it'll do nothing.
* Install nuget from MyGet: https://nugetized.blob.core.windows.net/live-reload/index.json
* Install vs extension in VS17: https://bosstoragemirror.azureedge.net/xvs-live-reload/a9/a90a2ce159435d6cdb3792b98be50035fda6d524/Xamarin.LiveReload.0.2.163.vsix

### Xamarin.Essentials
* https://www.myget.org/F/xamarin-essentials/api/v3/index.json

## App Activities

Activity: Change color theme from a provided set of colors. Introduces user to styling.
Verify: View on Live Reload (or other)

Activity: Add an image (background) from provided set of options
Verify: View on Live Reload on save

Activity: Add navigation from one screen to screen that uses Vision
Verify: Save and navigate by clicking on the simulator. Screen reports activity connecting to Vision and alerts user to do the next activity to connect.

Activity: Connect app to Cognitive Services Vision
Verify: Save and navigate to screen using Vision and see tags populate

Activity: Implement a FlexLayout for Search Results
Verify: View on Live Reload on save


## Other activities? 

connect social share?

Other services?


When will we have access to the machines?
Where will they be?